#!/bin/bash
# L3-Emotion-Router: One-shot setup for Termux
# Run: bash setup.sh

set -e

echo "=== L3-Emotion-Router Setup ==="

# 1. System packages
echo "[1/5] Installing packages..."
pkg update -y
pkg install -y git cmake clang jq termux-api

# 2. Storage access
echo "[2/5] Setting up storage..."
termux-setup-storage || true

# 3. Build llama.cpp
echo "[3/5] Building llama.cpp (this takes a few minutes)..."
cd ~
if [ ! -d "llama.cpp" ]; then
    git clone https://github.com/ggml-org/llama.cpp.git
fi
cd llama.cpp
mkdir -p build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build . --config Release -j4

echo "llama-server version:"
~/llama.cpp/build/bin/llama-server --version

# 4. Set up edge_router directory
echo "[4/5] Setting up edge_router..."
mkdir -p ~/edge_router
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cp "$SCRIPT_DIR/schema.gbnf" ~/edge_router/schema.gbnf
cp "$SCRIPT_DIR/run.sh" ~/edge_router/run.sh
chmod +x ~/edge_router/run.sh

# 5. Check model file
echo "[5/5] Checking model..."
MODEL_PATH="$HOME/storage/shared/gguf_BaseModels/Qwen3.5-4B-Q4_K_M.gguf"
if [ -f "$MODEL_PATH" ]; then
    echo "Model found: $MODEL_PATH"
    ls -lh "$MODEL_PATH"
else
    echo "WARNING: Model not found at $MODEL_PATH"
    echo "Download Qwen3.5-4B-Q4_K_M.gguf from:"
    echo "  https://huggingface.co/unsloth/Qwen3.5-4B-GGUF"
    echo "Place it at: $MODEL_PATH"
fi

# API key reminder
echo ""
echo "=== Setup Complete ==="
echo ""
echo "Remaining steps:"
echo "  1. Place model at: $MODEL_PATH"
echo "  2. Install Termux:API app from F-Droid (separate APK)"
echo "  3. Set API key:"
echo "     echo 'export OPENAI_API_KEY=\"sk-...\"' >> ~/.bashrc"
echo "     source ~/.bashrc"
echo "     chmod 600 ~/.bashrc"
echo "  4. Run: cd ~/edge_router && bash run.sh"
